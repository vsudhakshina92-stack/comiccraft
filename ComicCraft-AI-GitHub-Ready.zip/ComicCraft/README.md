# ComicCraft ✨ – AI Comic Story Creator

ComicCraft is a web-based AI comic story creator that transforms a user's idea into a four-panel comic story.

## Features
- Create comic stories from prompts
- Custom title and character
- Choose setting, tone and art style
- Generate a four-panel comic
- Preview and download the comic
- Export a PDF

## Tech Stack
- Frontend: React + Vite
- Styling: CSS
- Backend: Node.js + Express

## Live Demo
https://comic-craft-ai-98.lovable.app

## Developed By
**Sudhakshina**
