import express from "express";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json());

app.get("/", (_, res) => res.json({
  name: "ComicCraft API",
  status: "running"
}));

app.post("/api/generate", (req, res) => {
  const { title, character, setting, tone, prompt } = req.body;
  if (!title || !character || !prompt) {
    return res.status(400).json({ error: "title, character and prompt are required" });
  }
  res.json({
    panels: [
      { title: "The Beginning", text: `${character} starts the adventure in ${setting}. ${prompt}` },
      { title: "The Problem", text: `A ${tone} challenge appears.` },
      { title: "The Turning Point", text: `${character} finds a way forward.` },
      { title: "The Ending", text: `${character} completes the adventure.` }
    ]
  });
});

app.listen(5000, () => console.log("ComicCraft backend running on http://localhost:5000"));
