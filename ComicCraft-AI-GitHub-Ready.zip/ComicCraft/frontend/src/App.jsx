import React, { useState } from "react";
import { jsPDF } from "jspdf";

const styles = ["Comic Book", "Anime", "Cartoon", "Manga", "Watercolor"];
const tones = ["Funny", "Adventure", "Mystery", "Fantasy", "Emotional"];

function makePanels(title, character, setting, tone, prompt) {
  return [
    { title: "Panel 1 – The Beginning", text: `${character} enters ${setting}. The story begins with: ${prompt}` },
    { title: "Panel 2 – The Problem", text: `A ${tone.toLowerCase()} situation appears, and ${character} must decide what to do next.` },
    { title: "Panel 3 – The Turning Point", text: `${character} takes action and discovers an unexpected clue connected to the adventure.` },
    { title: "Panel 4 – The Ending", text: `${character} solves the main problem and reaches the end of "${title}".` }
  ];
}

export default function App() {
  const [title, setTitle] = useState("");
  const [character, setCharacter] = useState("");
  const [setting, setSetting] = useState("A magical city");
  const [tone, setTone] = useState("Adventure");
  const [style, setStyle] = useState("Comic Book");
  const [prompt, setPrompt] = useState("");
  const [panels, setPanels] = useState([]);

  function generateComic(e) {
    e.preventDefault();
    if (!title || !character || !prompt) {
      alert("Please enter a title, character and story prompt.");
      return;
    }
    setPanels(makePanels(title, character, setting, tone, prompt));
  }

  function downloadText() {
    const text = `${title}\n\n${panels.map(p => `${p.title}\n${p.text}`).join("\n\n")}`;
    const blob = new Blob([text], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${title.replace(/[^a-z0-9]/gi, "-") || "comic"}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function exportPDF() {
    const pdf = new jsPDF();
    pdf.setFontSize(20);
    pdf.text(title || "ComicCraft Story", 15, 20);
    pdf.setFontSize(11);
    let y = 35;
    panels.forEach((p) => {
      pdf.setFontSize(14);
      pdf.text(p.title, 15, y);
      y += 8;
      pdf.setFontSize(10);
      const lines = pdf.splitTextToSize(p.text, 175);
      pdf.text(lines, 15, y);
      y += lines.length * 5 + 12;
      if (y > 270) { pdf.addPage(); y = 20; }
    });
    pdf.save(`${title || "comic"}.pdf`);
  }

  return (
    <div className="app">
      <header>
        <div className="logo">✨ ComicCraft</div>
        <span>AI Comic Story Creator</span>
      </header>

      <main>
        <section className="hero">
          <h1>Create Your Own Comic</h1>
          <p>Turn your imagination into a four-panel comic story.</p>
        </section>

        <form className="card" onSubmit={generateComic}>
          <label>Comic Title
            <input value={title} onChange={e => setTitle(e.target.value)} placeholder="Enter your comic title" />
          </label>

          <label>Main Character
            <input value={character} onChange={e => setCharacter(e.target.value)} placeholder="Describe your main character" />
          </label>

          <label>Setting
            <input value={setting} onChange={e => setSetting(e.target.value)} />
          </label>

          <div className="row">
            <label>Tone
              <select value={tone} onChange={e => setTone(e.target.value)}>
                {tones.map(x => <option key={x}>{x}</option>)}
              </select>
            </label>
            <label>Art Style
              <select value={style} onChange={e => setStyle(e.target.value)}>
                {styles.map(x => <option key={x}>{x}</option>)}
              </select>
            </label>
          </div>

          <label>Story Prompt
            <textarea value={prompt} onChange={e => setPrompt(e.target.value)} placeholder="Describe what should happen in your comic..." />
          </label>

          <button className="primary">✨ Create My Comic</button>
        </form>

        {panels.length > 0 && (
          <section className="results">
            <div className="result-head">
              <div>
                <h2>{title}</h2>
                <p>{style} · {tone} · {setting}</p>
              </div>
              <div className="actions">
                <button onClick={downloadText}>Download</button>
                <button onClick={exportPDF}>Export PDF</button>
              </div>
            </div>

            <div className="grid">
              {panels.map((p, i) => (
                <article className="panel" key={i}>
                  <div className="panel-art">Panel {i + 1}</div>
                  <h3>{p.title}</h3>
                  <p>{p.text}</p>
                </article>
              ))}
            </div>
          </section>
        )}
      </main>

      <footer>Developed by Sudhakshina · ComicCraft</footer>
    </div>
  );
}
